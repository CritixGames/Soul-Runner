package com.tutorial.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class EnemyBoss2 extends GameObject{
	
	private Handler handler;
	
	//Parameterized constructor
	public EnemyBoss2(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		
		this.handler = handler;
		
		//default velocities of Basic Enemy
		velX = 5;
		velY = 5;
	}
	public Rectangle getBounds() {
		return new Rectangle((int)x,(int)y,120,120);
	}


	@Override
	public void tick() 
	{
		x += velX;
		y += velY;
		
		//Boundries Collision
		if (y <= 0 || y>= Game.HEIGHT-128) velY *= -1;
		if (x <= 0 || x>= Game.WIDTH-128) velX *= -1;
		
		handler.addObject(new Trail((int)x,(int)y,ID.Trail,Color.red,120,120,0.07f, handler));
	}

	@Override
	public void render(Graphics g) 
	{
		g.setColor(Color.red);
		g.fillRect((int)x,(int)y,120,120);
	}

}
