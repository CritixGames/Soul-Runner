package com.tutorial.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.Random;

public class Game extends Canvas implements Runnable{

	//initialization of fields
	public static final int WIDTH = 640, HEIGHT = WIDTH/12 * 9; //setting size of Frame
	
	private Thread thread;
	private boolean running = false;
	
	private Random r;
	private Handler handler;
	private HUD hud;
	private Spawn spawner;
	private Menu menu;
	
	public enum STATE
	{
		Menu,
		Help,
		Game,
		End
	};
	
	public static STATE gameState = STATE.Menu;
	
	
	//constructor
	public Game()
	{
		handler = new Handler(); //handler before window to avoid random errors
		hud = new HUD(); //initialize HUD
		menu = new Menu(this, handler, hud);
		this.addKeyListener(new KeyInput(handler)); //listen to event key press for key input class
		
		this.addMouseListener(menu);
		
		new Window(WIDTH, HEIGHT, "Let's Build a Game!",this); //invoke window constructor to create new window
		

		spawner = new Spawn(handler,hud);//under HUD ALWAYS
		r = new Random(); //initialize random variable
		
		if(gameState == STATE.Game) 
		{
			handler.addObject(new Player(WIDTH/2-32,HEIGHT/2-32,ID.Player,handler)); //new white rectangle at random position in interval of WIDTH & HEIGHT with personal ID player.
			handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
		}else {
			for(int i = 0;i <20;i++) {
				handler.addObject(new MenuParticle(r.nextInt(WIDTH),r.nextInt(HEIGHT),ID.MenuParticle,handler));
			}
		}
		
		
	}
	
	//threads
	public synchronized void start() 
	{
		thread = new Thread(this); //virtual CPU that execute java code
		thread.start();	
		running = true;
	}
	
	public synchronized void stop() 
	{
		try {
			thread.join(); //stopping thread
			running=false;
			}
		catch(Exception e){
			e.printStackTrace();//Run an Error Bug in console
			}
	}
	
	public void run() 
	{
		//GAME LOOP (Notch loop) popular game loop
		//essentially we calculate the Frames Per Second here
		this.requestFocus(); //don't need to click on screen to get keyboard game access
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		while (running) 
		{
			long now = System.nanoTime();
			delta += (now - lastTime)/ ns;
			lastTime = now;
			while(delta >= 1) //reset delta to 0
			{
				tick();
				delta--;
			}
			if (running)
				render();
			frames++;
			
			if(System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println("FPS: " + frames);
				frames = 0;
			}
		}
		stop();
	}
	
	private void tick() 
	{	
		handler.tick();
		
		if(gameState == STATE.Game) 
		{
			hud.tick();
			spawner.tick();
			
			if(HUD.HEALTH <= 0) {
				HUD.HEALTH = 100;
				gameState = STATE.End;
				handler.clearEnemies();
				for(int i = 0;i <20;i++) {
					handler.addObject(new MenuParticle(r.nextInt(WIDTH),r.nextInt(HEIGHT),ID.MenuParticle,handler));
				}
			}
		}else if(gameState == STATE.Menu || gameState == STATE.End) {
			menu.tick();
			
		}
		
		

	}
	
	private void render() 
	{
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) 
		{
			this.createBufferStrategy(3); //making 3 buffers in our game
			return;
		}
		
		//frames stuff
		Graphics g = bs.getDrawGraphics();
		
		g.setColor(Color.DARK_GRAY); //set background
		g.fillRect(0,0,WIDTH,HEIGHT);
		
		handler.render(g);
		
		if(gameState == STATE.Game)
		{
			 hud.render(g);
		}
		else if(gameState == STATE.Menu || gameState == STATE.Help || gameState == STATE.End) {
			menu.render(g);
		}
		g.dispose();
		bs.show();
	}
	//static method for boundries
	public static float clam(float var, float min, float max) 
	{
		if(var >= max)
			return var = max;
		else if(var<=min)
			return var = min;
		else
			return var;
	}
	
public static void main(String args[]){
	new Game();
	
}
}
