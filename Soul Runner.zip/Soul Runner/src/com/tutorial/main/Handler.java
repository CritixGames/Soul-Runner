package com.tutorial.main;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.LinkedList;

public class Handler 
{
	//linked list for game Objects (object is the name of LinkedList)
	ArrayList<GameObject> object = new ArrayList<GameObject>();
	
	//thick method
	public void tick() {
		for (int i = 0; i < object.size();i++) {
			GameObject tempObject = object.get(i);
			
			tempObject.tick();
			}
		}
	
	//graphics render method
	public void render(Graphics g) {
		for(int i=0;i<object.size();i++) {
			GameObject tempObject = object.get(i);
			
			tempObject.render(g);
		}
	}
	
	public void clearEnemies() {
		for(int i=0;i<object.size();i++) {
			GameObject tempObject = object.get(i);
			
			if(tempObject.getId() != ID.Player) {
				object.clear();
				if(Game.gameState != Game.STATE.End)
				addObject(new Player((int)tempObject.getX(),(int)tempObject.getY(),ID.Player,this));
			}
	}
}
	
	//method to add an object
	public void addObject(GameObject object) {
		this.object.add(object);
		}
	//method to remove an object
	public void removeObject(GameObject object) {
		this.object.remove(object);
	}
}
