package com.tutorial.main;
//creating different id to let the game know which is the player, which is enemy,etc.
public enum ID {

	Player(),
	Trail,
	BasicEnemy(),
	FastEnemy(),
	SmartEnemy(),
	EnemyBoss(),
	EnemyBoss2(),
	MenuParticle();
}
