package com.tutorial.main;

import java.util.Random;

public class Spawn {

	private Handler handler;
	private HUD hud;
	private Random r = new Random();
	
	private int scoreKeep = 0;
	
	public Spawn(Handler handler,HUD hud) {
		this.handler = handler;
		this.hud=hud;
	}
	
	public void tick() {
		scoreKeep++;
		
		if(scoreKeep >= 700) {
			scoreKeep = 0;
			hud.setLevel(hud.getlevel()+1);
			
			if(hud.getlevel() == 2) 
			{
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
			}
			else if(hud.getlevel() == 3) 
			{
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.FastEnemy,handler));
			}
			else if(hud.getlevel() == 4) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 5) {
				handler.clearEnemies();
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.FastEnemy,handler));
				//handler.addObject(new EnemyBoss(Game.WIDTH/2 - 48,-120,ID.EnemyBoss,handler));
				//handler.addObject(new EnemyBoss2(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.EnemyBoss2,handler));
			}
			else if(hud.getlevel() == 6) {
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.FastEnemy,handler));
			}
			else if(hud.getlevel() == 7) {
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.FastEnemy,handler));
			}
			else if(hud.getlevel() == 8) {
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.FastEnemy,handler));
			}
			else if(hud.getlevel() == 9) {
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.FastEnemy,handler));
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 10) {
				handler.clearEnemies();
				handler.addObject(new EnemyBoss2(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.EnemyBoss2,handler));
			}
			else if(hud.getlevel() == 11) {
				handler.clearEnemies();
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 12) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 13) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
			}
			else if(hud.getlevel() == 14) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 15) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
			}
			else if(hud.getlevel() == 16) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 17) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
			}
			else if(hud.getlevel() == 18) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
			}
			else if(hud.getlevel() == 19) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.SmartEnemy,handler));
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 50),r.nextInt(Game.HEIGHT - 50),ID.BasicEnemy,handler));
			}
			else if(hud.getlevel() == 20) {
				handler.clearEnemies();
				handler.addObject(new EnemyBoss(Game.WIDTH/2 - 48,-120,ID.EnemyBoss,handler));
			}
	}
}
}