package com.tutorial.main;

import java.awt.Canvas; //ctrl shift o (to import needed libraries)
import java.awt.Dimension;
import javax.swing.JFrame;

public class Window extends Canvas {

	private static final long serialVersionUTD = -2408440600533728354L; //game serial number
	
	public Window(int width, int height, String title, Game game) {
		
		JFrame frame = new JFrame(title); //frame of window using JFrame
		
		//setting size of window (constructor) as well as minimum and maximum
		frame.setPreferredSize(new Dimension(width, height));
		frame.setMaximumSize(new Dimension(width, height));
		frame.setMinimumSize(new Dimension(width, height));
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //setting the x button to actually exit game
		frame.setResizable(false); //avoiding problems by setting the frame to unresizeable
		frame.setLocationRelativeTo(null);//making frame start up on middle of screen.
		frame.add(game); //adding game class into FRAME
		frame.setVisible(true); //setting Frame to be visible
		game.start(); //starting game method
	}
}
